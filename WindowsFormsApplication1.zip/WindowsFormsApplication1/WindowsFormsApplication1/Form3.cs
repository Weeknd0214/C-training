﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Threading;
namespace WindowsFormsApplication1
{

    public partial class Form3 : Form
    {
        public Form OwnerForm;
        public Form3(int _Minimum, int _Maximum, Form _OwnerForm)//带参数，表示进度条的范围的最小值和最大值
        {
            InitializeComponent();
            progressBar1.Maximum=_Maximum;//设置范围最大值
            progressBar1.Value = progressBar1.Minimum  = _Minimum;//设置范围最小值
            this.OwnerForm = _OwnerForm;
        }
        public void setPos(int value)//设置进度条当前进度值
        {
            if (value < progressBar1.Maximum)//如果值有效

            {
                progressBar1.Value = value;//设置进度值
                label5.Text = (value * 100 / progressBar1.Maximum).ToString() + "%";//显示百分比
            }//(进度值/100)/总值
            Application.DoEvents();//不加父子窗体都会假死 其实全部用线程会好做 这个会降低效率
        }
        private void Form2_Load(object sender, EventArgs e)
        {
            this.OwnerForm.Enabled = false;//设置父窗体不可用
        }
        private void Form2_FormClosed(object sender, FormClosedEventArgs e)
        {
            this.OwnerForm.Enabled = true;//回复父窗体为可用
        }
    }

       

    }
        
       
 
 
    


