﻿namespace WindowsFormsApplication1 {
    
    
    public partial class DataSet2 {
        partial class DataTable2DataTable
        {
        }
    }
}
