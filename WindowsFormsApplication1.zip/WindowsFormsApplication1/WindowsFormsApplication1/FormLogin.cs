﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Threading;
namespace WindowsFormsApplication1
{
    public partial class FormLogin : Form
    {
        public FormLogin()
        {
            //Form3 fm1 = new Form3(0, 100, this);
            //fm1.Show();//设置父窗体
            //for (int i = 0; i < 100; i++)
            //{
            //    fm1.setPos(i);//设置进度条位置
            //    Thread.Sleep(80);//睡眠时间为100
            //}
            //fm1.Close();//关闭窗体
            InitializeComponent();
            
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Form1 fm = new Form1();
            this.Hide();
            fm.Show();

          
        }

        private void button1_Click(object sender, EventArgs e)
        {
            
            int userID = int.Parse(textBox1.Text);
            int? n = queriesTableAdapter1.UserLogin(userID, textBox2.Text);
            if (n > 0)
            {
                FormUser fm = new FormUser(userID);
                this.Hide();
                fm.Show();
            }
        }

        private void FormLogin_Load(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            

                    textBox1.Clear();
                    textBox2.Clear();

                }
            }
        }
//    }
//}
