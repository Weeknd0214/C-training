﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class Form2 : Form
    {
        public Form2(int bookID)
        {
            InitializeComponent();
            this.bookID = bookID;
        }
        int bookID;
        private void groupBox2_Enter(object sender, EventArgs e)
        {

        }

        private void Form2_Load(object sender, EventArgs e)
        {
            this.dataTable2TableAdapter.FillByID(this.dataSet2.DataTable2, bookID);
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void numericUpDown1_ValueChanged(object sender, EventArgs e)
        {
            float zj = Convert.ToSingle(numericUpDown1.Value) * float.Parse(textBox7.Text);
            textBox9.Text = string.Format("{0:f1}",zj) + "元";
        }


        public static string info="";

        private void button1_Click(object sender, EventArgs e)
        {
            if (numericUpDown1.Value <= 0)
            {
                MessageBox.Show("购买数量不能为0");
                return;
            }
            if (!radioButton1.Checked && !radioButton2.Checked)
            {
                MessageBox.Show("请选择付款方式");
                return;
            }
            if (info != "")
            {
                info = info.Substring(0, info.LastIndexOf('，') + 1);
            }
            info = info + "你已经购买了《" + textBox2.Text + "》书(" + numericUpDown1.Value + ")本，请到前台取书。";
            MessageBox.Show("付款成功！");
            this.Close();
        }
    }
}
