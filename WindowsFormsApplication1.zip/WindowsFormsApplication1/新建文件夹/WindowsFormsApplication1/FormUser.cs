﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace WindowsFormsApplication1
{
    public partial class FormUser : Form
    {
        public FormUser(int userID)
        {
            InitializeComponent();
            this.userID = userID;
        }

        int userID;

        private void FormUser_Load(object sender, EventArgs e)
        {
            // TODO: 这行代码将数据加载到表“dataSet21.DataTable1”中。您可以根据需要移动或删除它。
            this.dataTable1TableAdapter.Fill1(this.dataSet21.DataTable1);
            string userName = queriesTableAdapter1.ScalarQuery_GetUserName(userID);
            label1.Text = "欢迎你," + userName;
            usersTableAdapter1.Fill_GetPHOTO(this.dataSet21.Users, userID);
            ReloadTreeView();
            treeView1.Nodes[0].Checked = true;
        }

        void ReloadTreeView()   //加载分类到TreeView
        {
            treeView1.Nodes.Clear();
            this.bookCatagorys1TableAdapter1.Fill(this.dataSet11.BookCatagorys1);
            TreeNode rootNode = new TreeNode("全部分类");
            for (int i = 0; i < dataSet11.BookCatagorys1.Rows.Count; i++)
            {
                if (dataSet11.BookCatagorys1.Rows[i]["ParentID"].ToString() == "")
                {
                    TreeNode tn1 = new TreeNode(dataSet11.BookCatagorys1.Rows[i]["CatagoryName"].ToString());
                    for (int j = 0; j < dataSet11.BookCatagorys1.Rows.Count; j++)
                    {
                        if (dataSet11.BookCatagorys1.Rows[j]["ParentID"].ToString() == dataSet11.BookCatagorys1.Rows[i]["CatagoryID"].ToString())
                        {
                            TreeNode tn2 = new TreeNode(dataSet11.BookCatagorys1.Rows[j]["CatagoryName"].ToString());
                            tn1.Nodes.Add(tn2);
                        }
                    }
                    rootNode.Nodes.Add(tn1);
                }
            }
            treeView1.Nodes.Add(rootNode);
            treeView1.ExpandAll();
        }

        private void treeView1_AfterCheck(object sender, TreeViewEventArgs e)
        {
            if (e.Node.Checked)
            {
                foreach (TreeNode tn1 in e.Node.Nodes)
                {
                    tn1.Checked = true;
                    foreach (TreeNode tn2 in tn1.Nodes)
                    {
                        tn2.Checked = true;
                    }
                }
            }
            else
            {
                foreach (TreeNode tn1 in e.Node.Nodes)
                {
                    tn1.Checked = false;
                    foreach (TreeNode tn2 in tn1.Nodes)
                    {
                        tn2.Checked = false;
                    }
                }
            }
        }

        string catagoryTJ;  //图书类别条件

        //搜索
        private void button1_Click(object sender, EventArgs e)
        {
            GetCatagoryTJ();

           
            string conn = "Data Source=.; Initial Catalog=书店数据库; Integrated Security=True";
            SqlConnection sqlcon = new SqlConnection(conn);
            sqlcon.Open();

            string sql;
            
            sql = "SELECT BookID, CatagoryName, Author, PressName, SoledPrice, BookCover, StoredNum, SoledNum, AddDate "+
                         "FROM BookStores INNER JOIN BookCatagorys ON BookStores.CatagoryIDx = BookCatagorys.CatagoryID "+
                         "where (CatagoryName like '%" + textBox1.Text + "%' or Author like '%" + textBox1.Text + "%' or PressName like '%"+ textBox1.Text +"%') ";
            if (catagoryTJ != "")
                sql += "AND CatagoryName IN (" + catagoryTJ +")";
            MessageBox.Show(sql);
            SqlDataAdapter da = new SqlDataAdapter(sql, sqlcon);
            DataSet ds = new DataSet();
            da.Fill(ds);
            dataGridView1.DataSource = ds.Tables[0];

            sqlcon.Close();
        }

        void GetCatagoryTJ()
        {
            catagoryTJ = "";
            foreach (TreeNode tn1 in treeView1.Nodes[0].Nodes)
            {
                foreach (TreeNode  tn2  in tn1.Nodes)
                {
                    if (tn2.Checked)
                    {
                        catagoryTJ += "'" + tn2.Text + "',";
                    }
                }
            }
            catagoryTJ = catagoryTJ.Trim(',');
        }

    }
}
