﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace WindowsFormsApplication1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // TODO: 这行代码将数据加载到表“dataSet1.DataTable1”中。您可以根据需要移动或删除它。
            this.dataTable1TableAdapter.FillAll(this.dataSet1.DataTable1);
            DisableEdit();

            ReloadTreeView();
        }

        void ReloadTreeView()   //加载分类到TreeView
        {
            treeView1.Nodes.Clear();
            this.bookCatagorys1TableAdapter1.Fill(this.dataSet1.BookCatagorys1);
            TreeNode rootNode = new TreeNode("全部分类");
            for (int i = 0; i < dataSet1.BookCatagorys1.Rows.Count; i++)
            {
                if (dataSet1.BookCatagorys1.Rows[i]["ParentID"].ToString() == "")
                {
                    TreeNode tn1 = new TreeNode(dataSet1.BookCatagorys1.Rows[i]["CatagoryName"].ToString());
                    for (int j = 0; j < dataSet1.BookCatagorys1.Rows.Count; j++)
                    {
                        if (dataSet1.BookCatagorys1.Rows[j]["ParentID"].ToString() == dataSet1.BookCatagorys1.Rows[i]["CatagoryID"].ToString())
                        {
                            TreeNode tn2 = new TreeNode(dataSet1.BookCatagorys1.Rows[j]["CatagoryName"].ToString());
                            tn1.Nodes.Add(tn2);
                        }
                    }
                    rootNode.Nodes.Add(tn1);
                }
            }
            treeView1.Nodes.Add(rootNode);
            treeView1.ExpandAll();
        }

        void DisableEdit()
        {
            textBox1.Enabled = false;
            textBox2.Enabled = false;
            comboBox1.Enabled = false;
            textBox4.Enabled = false;
            textBox5.Enabled = false;
            textBox6.Enabled = false;
            textBox7.Enabled = false;
            textBox8.Enabled = false;
            textBox9.Enabled = false;
            textBox10.Enabled = false;
            textBox1.Enabled = false;
            button1.Enabled = false;
            button5.Enabled = false;
            button6.Enabled = false;
            dataGridView1.Enabled = true;
        }

        void EnableEdit()
        {
            //textBox1.Enabled = true;
            textBox2.Enabled = true;
            comboBox1.Enabled = true;
            textBox4.Enabled = true;
            textBox5.Enabled = true;
            textBox6.Enabled = true;
            textBox7.Enabled = true;
            textBox8.Enabled = true;
            textBox9.Enabled = true;
            textBox10.Enabled = true;
            textBox1.Enabled = true;
            button1.Enabled = true;
            button5.Enabled = true;
            button6.Enabled = true;
            dataGridView1.Enabled = false;
        }

        void DisableButtons()
        {
            button2.Enabled = false;
            button3.Enabled = false;
            button4.Enabled = false;
        }

        void EnableButtons()
        {
            button2.Enabled = true;
            button3.Enabled = true;
            button4.Enabled = true;
        }

        void ResetCombox1()
        {
            comboBox1.Items.Clear();
            bookCatagorysTableAdapter1.Fill(this.dataSet1.BookCatagorys);
            for (int i = 0; i < dataSet1.BookCatagorys.Rows.Count; i++)
            {
                comboBox1.Items.Add(dataSet1.BookCatagorys.Rows[i][0].ToString());
            }
        }

        //新增
        private void button2_Click(object sender, EventArgs e)
        {
            EnableEdit();
            dataTable1BindingSource.AddNew();
            DisableButtons();
            ResetCombox1();
            operation = Operation.新增;
            textBox1.Text = "";
        }

        enum Operation { 新增, 修改, 不确定 };
        Operation operation = Operation.不确定;

        bool IsAllTextBoxFill()
        {
            bool b= true;
            foreach (Control c in groupBox1.Controls)
            {
                if (c as TextBox == null)
                    continue;
                if (c.Text.Trim() == "")
                    b = false;
            }
            return b;
        }


        private void SaveNewBook()
        {
            //1、获取图书类别编号
            int? catagoryID = queriesTableAdapter1.ScalarQuery_GetCatagoryID(comboBox1.Text);
            //2、插入新书
            queriesTableAdapter1.InsertQuery_NEWBOOK(textBox2.Text, catagoryID, textBox4.Text, textBox5.Text, float.Parse(textBox6.Text),
                             float.Parse(textBox7.Text), int.Parse(textBox8.Text), int.Parse(textBox9.Text), DateTime.Parse(textBox10.Text));
            //3、获取刚才插入新书的ID
            int? bookID = queriesTableAdapter1.ScalarQuery_GetBookID();
            //4、更新刚才插入新书封面
            string conn = "Data Source=.; Initial Catalog=书店数据库; Integrated Security=True";
            SqlConnection sqlcon = new SqlConnection(conn);
            sqlcon.Open();
            SqlCommand cmd = new SqlCommand();
            cmd.CommandText = "update BookStores set BookCover=(select * from OPENROWSET(BULK N'" + fileName + "',SINGLE_BLOB) AS DOCUMENT) where BookID=" + bookID;
            cmd.Connection = sqlcon;
            cmd.ExecuteNonQuery();
            sqlcon.Close();
            MessageBox.Show("增加新书成功！");
        }

        void ModifyBook()
        {
            //1、获取图书类别编号
            int? catagoryID = queriesTableAdapter1.ScalarQuery_GetCatagoryID(comboBox1.Text);
            //2、更新新书
            queriesTableAdapter1.UpdateQuery_UPDATEbook(textBox2.Text, catagoryID, textBox4.Text, textBox5.Text, float.Parse(textBox6.Text),
                             float.Parse(textBox7.Text), int.Parse(textBox8.Text), int.Parse(textBox9.Text), DateTime.Parse(textBox10.Text),int.Parse(textBox1.Text));
            //4、更新图书书封面
            if (fileName != "")
            {
                string conn = "Data Source=.; Initial Catalog=书店数据库; Integrated Security=True";
                SqlConnection sqlcon = new SqlConnection(conn);
                sqlcon.Open();
                SqlCommand cmd = new SqlCommand();
                cmd.CommandText = "update BookStores set BookCover=(select * from OPENROWSET(BULK N'" + fileName + "',SINGLE_BLOB) AS DOCUMENT) where BookID=" + textBox1.Text;
                cmd.Connection = sqlcon;
                cmd.ExecuteNonQuery();
                sqlcon.Close();
            }
            MessageBox.Show("修改图书成功！");

        }

        //修改
        private void button3_Click(object sender, EventArgs e)
        {
            EnableEdit();
            DisableButtons();
            ResetCombox1();
            operation = Operation.修改;
        }

        //删除
        private void button4_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("是否确定要删除该图书?", "提示", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                queriesTableAdapter1.DeleteQuery_deleteBook(int.Parse(textBox1.Text));
                MessageBox.Show("删除图书成功");
                Form1_Load(null, null);
            }
        }

        //保存
        private void button5_Click(object sender, EventArgs e)
        {
            DisableEdit();
            EnableButtons();
            if (!IsAllTextBoxFill())
            {
                MessageBox.Show("图书信息填写不完整，操作失败，请填写完整再保存");
                dataTable1BindingSource.CancelEdit();
                return;
            }
            if (operation == Operation.新增)
                SaveNewBook();
            else if(operation == Operation.修改)
                ModifyBook();
            Form1_Load(null, null);
        }

        //取消
        private void button6_Click(object sender, EventArgs e)
        {
            DisableEdit();
            EnableButtons();

            dataTable1BindingSource.CancelEdit() ;
        }

        string fileName="";
        private void button1_Click(object sender, EventArgs e)
        {
            if (openFileDialog1.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                fileName = openFileDialog1.FileName;
                pictureBox1.ImageLocation = fileName;
            }
        }

        //添加分类
        private void button7_Click(object sender, EventArgs e)
        {
            if (treeView1.SelectedNode == null || textBox3.Text == "")
            {
               MessageBox.Show("必须选择分类节点，且必须输入新分类名称");
               return;
            }

            TreeNode tn = treeView1.SelectedNode;
            if (tn.Level == 2)
                tn = tn.Parent;
            //获取 分类名称 所对应的分类编号
            int? catagoryID = queriesTableAdapter1.ScalarQuery_GetCatagoryID(tn.Text);
            //插入新分类
            queriesTableAdapter1.InsertQuery_InsertCatagory(textBox3.Text, catagoryID);

            ReloadTreeView();
        }

        private void button8_Click(object sender, EventArgs e)
        {
            if (treeView1.SelectedNode == null || textBox3.Text == "")
            {
                MessageBox.Show("必须选择分类节点，且必须输入新分类名称");
                return;
            }

            TreeNode tn = treeView1.SelectedNode;
            //获取 分类名称 所对应的分类编号
            int? catagoryID = queriesTableAdapter1.ScalarQuery_GetCatagoryID(tn.Text);
            //修改新分类
            queriesTableAdapter1.UpdateQuery_UpdateCatagory(textBox3.Text, catagoryID.Value);

            ReloadTreeView();
        }

        private void button9_Click(object sender, EventArgs e)
        {
            if (treeView1.SelectedNode == null )
            {
                MessageBox.Show("必须选择删除分类节点");
                return;
            }

            TreeNode tn = treeView1.SelectedNode;
            //获取 分类名称 所对应的分类编号
            int? catagoryID = queriesTableAdapter1.ScalarQuery_GetCatagoryID(tn.Text);
            //删除新分类
            queriesTableAdapter1.DeleteQuery_DeleteCatagory(catagoryID.Value);

            ReloadTreeView();
        }

    }
}
